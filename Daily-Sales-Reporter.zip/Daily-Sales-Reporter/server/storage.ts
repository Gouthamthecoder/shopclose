import { eq, and, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import {
  type User, type InsertUser,
  type ShopSettings, type InsertShopSettings,
  type DailyClosing, type InsertDailyClosing,
  users, shopSettings, dailyClosings,
} from "@shared/schema";

const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
});

export const db = drizzle(pool);

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser & { role?: string }): Promise<User>;

  getSettings(): Promise<ShopSettings>;
  updateSettings(data: Partial<InsertShopSettings>): Promise<ShopSettings>;

  getClosingByDate(date: string): Promise<DailyClosing | undefined>;
  getClosingsByDateRange(from: string, to: string): Promise<DailyClosing[]>;
  createClosing(data: InsertDailyClosing): Promise<DailyClosing>;
  updateClosing(id: number, data: Partial<InsertDailyClosing>): Promise<DailyClosing>;
  getAllClosings(): Promise<DailyClosing[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser & { role?: string }): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getSettings(): Promise<ShopSettings> {
    const [existing] = await db.select().from(shopSettings);
    if (existing) return existing;
    const [created] = await db.insert(shopSettings).values({ shopName: "My Shop" }).returning();
    return created;
  }

  async updateSettings(data: Partial<InsertShopSettings>): Promise<ShopSettings> {
    const current = await this.getSettings();
    const [updated] = await db
      .update(shopSettings)
      .set(data as any)
      .where(eq(shopSettings.id, current.id))
      .returning();
    return updated;
  }

  async getClosingByDate(date: string): Promise<DailyClosing | undefined> {
    const [closing] = await db.select().from(dailyClosings).where(eq(dailyClosings.date, date));
    return closing;
  }

  async getClosingsByDateRange(from: string, to: string): Promise<DailyClosing[]> {
    return db
      .select()
      .from(dailyClosings)
      .where(and(gte(dailyClosings.date, from), lte(dailyClosings.date, to)))
      .orderBy(dailyClosings.date);
  }

  async createClosing(data: InsertDailyClosing): Promise<DailyClosing> {
    const [closing] = await db.insert(dailyClosings).values(data).returning();
    return closing;
  }

  async updateClosing(id: number, data: Partial<InsertDailyClosing>): Promise<DailyClosing> {
    const [closing] = await db
      .update(dailyClosings)
      .set(data)
      .where(eq(dailyClosings.id, id))
      .returning();
    return closing;
  }

  async getAllClosings(): Promise<DailyClosing[]> {
    return db.select().from(dailyClosings).orderBy(dailyClosings.date);
  }
}

export const storage = new DatabaseStorage();
