import { db } from "./storage";
import { dailyClosings, shopSettings, users } from "@shared/schema";
import { format, subDays } from "date-fns";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";

export async function seedDatabase() {
  const [existingAdmin] = await db.select().from(users).where(eq(users.username, "admin"));
  const hashedPassword = await bcrypt.hash("admin123", 10);
  if (!existingAdmin) {
    await db.insert(users).values({
      username: "admin",
      password: hashedPassword,
      role: "admin",
    });
    console.log("Seeded admin user: admin / admin123");
  } else if (!existingAdmin.password.startsWith("$2")) {
    await db.update(users).set({ password: hashedPassword }).where(eq(users.username, "admin"));
    console.log("Fixed admin password hash");
  }

  const [existingSettings] = await db.select().from(shopSettings);
  if (!existingSettings) {
    await db.insert(shopSettings).values({
      shopName: "Sri Lakshmi Stores",
      customFields: [
        { id: "field_1", label: "Staff Present", type: "number", section: "opening", enabled: true },
        { id: "field_2", label: "Pending Orders", type: "number", section: "closing", enabled: true },
      ],
    });
  }

  const [existingClosings] = await db.select().from(dailyClosings);
  if (!existingClosings) {
    const today = new Date();
    const seedData = [];
    for (let i = 6; i >= 0; i--) {
      const date = format(subDays(today, i), "yyyy-MM-dd");
      const cashSales = 5000 + Math.round(Math.random() * 10000);
      const upiSales = 3000 + Math.round(Math.random() * 8000);
      const cardSales = 1000 + Math.round(Math.random() * 5000);
      const expenses = 500 + Math.round(Math.random() * 2000);
      const visits = 20 + Math.round(Math.random() * 60);

      seedData.push({
        date,
        previousCashBalance: 10000 + Math.round(Math.random() * 5000),
        currentCashBalance: 12000 + Math.round(Math.random() * 8000),
        totalExpenses: expenses,
        expenseNotes: i === 0 ? "Electricity bill, cleaning supplies" : null,
        salesCash: cashSales,
        salesUpi: upiSales,
        salesCard: cardSales,
        totalCustomerVisits: visits,
        stockNotes: i === 0 ? "Low on rice and dal" : null,
        electricityMeterReading: 15200 + i * 12,
        customFieldValues: { field_1: 2 + Math.floor(Math.random() * 3), field_2: Math.floor(Math.random() * 5) },
        notes: null,
        status: "finalized",
        sentToWhatsapp: i > 0,
      });
    }
    await db.insert(dailyClosings).values(seedData);
  }
}
